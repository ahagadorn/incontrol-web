<?php
$host = 'localhost';
$port='1178';
$pass = 'mypass';
?>
